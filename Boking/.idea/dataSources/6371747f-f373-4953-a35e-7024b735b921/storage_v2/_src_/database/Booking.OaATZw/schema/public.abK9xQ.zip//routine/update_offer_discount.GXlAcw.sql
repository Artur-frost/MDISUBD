create function update_offer_discount() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE Offers
    SET discount = NEW.discount
    WHERE id_offer = NEW.offer_id;
    RETURN NEW;
END;
$$;

alter function update_offer_discount() owner to postgres;

