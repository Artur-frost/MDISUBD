create function log_user_action() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO ActionLog (action, action_date, user_id, description)
    VALUES (TG_OP, NOW(), NEW.id_user, 'User ' || NEW.id_user || ' ' || TG_OP);
    RETURN NEW;
END;
$$;

alter function log_user_action() owner to postgres;

