create function calculate_total_order_price() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE Orders
    SET total_price = (
        SELECT SUM(price_per_night * stay_days)
        FROM Offers
        WHERE id_offer = NEW.offer_id
    )
    WHERE id_order = NEW.id_order;
    RETURN NEW;
END;
$$;

alter function calculate_total_order_price() owner to postgres;

