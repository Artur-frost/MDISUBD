create procedure create_order(IN offer_id integer, IN order_date date, IN user_id integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO Orders (offer_id, order_date, user_id)
    VALUES (offer_id, order_date, user_id);
END;
$$;

alter procedure create_order(integer, date, integer) owner to postgres;

