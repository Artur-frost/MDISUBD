create procedure add_review(IN review_text character varying, IN rating integer, IN user_id integer, IN offer_id integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO Reviews (review_text, rating, user_id, offer_id)
    VALUES (review_text, rating, user_id, offer_id);
END;
$$;

alter procedure add_review(varchar, integer, integer, integer) owner to postgres;

