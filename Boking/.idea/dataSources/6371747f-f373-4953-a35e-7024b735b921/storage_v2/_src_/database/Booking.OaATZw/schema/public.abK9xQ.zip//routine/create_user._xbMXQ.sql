create procedure create_user(IN user_login character varying, IN user_password character varying, IN user_first_name character varying, IN user_last_name character varying, IN role_id integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO Users (user_login, user_password, user_first_name, user_last_name, role_id)
    VALUES (user_login, user_password, user_first_name, user_last_name, role_id);
END;
$$;

alter procedure create_user(varchar, varchar, varchar, varchar, integer) owner to postgres;

