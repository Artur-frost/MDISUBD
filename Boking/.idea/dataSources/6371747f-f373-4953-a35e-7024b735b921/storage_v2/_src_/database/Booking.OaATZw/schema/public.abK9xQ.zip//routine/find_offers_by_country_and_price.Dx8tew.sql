create procedure find_offers_by_country_and_price(IN country_name character varying, IN max_price double precision)
    language plpgsql
as
$$
BEGIN
    SELECT * FROM Offers
    WHERE country = country_name AND price_per_night <= max_price;
END;
$$;

alter procedure find_offers_by_country_and_price(varchar, double precision) owner to postgres;

